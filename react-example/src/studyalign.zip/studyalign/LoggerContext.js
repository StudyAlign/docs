import React from 'react';

export const LoggerContext = React.createContext(null);
